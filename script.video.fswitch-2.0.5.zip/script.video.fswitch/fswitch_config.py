# platform
osPlatform = None

# service config
radioOnPlayStop60 = None
radioOnPlayStop50 = None
radioNotifyOn = None

# service flags
radioOnPlayStart = None
activeService = None

# active info flag
activeInfo = None

# key mapping
radio60hz = None
radio50hz = None
radio24hz = None
radioAuto = None
radioInfo = None

key60hz = None
key50hz = None
key24hz = None
keyAuto = None
keyInfo = None

status60hz = None
status50hz = None
status24hz = None
statusAuto = None
statusInfo = None

keymapRes = None

# mode change
lastFreqChange = None

lastDetectedFps = None
lastDetectedFile = None

# auto-set configuration
radioAuto60hz = None
radioAuto50hz = None
radioAuto24hz = None

edit60hzFps1 = None
edit60hzFps2 = None
edit60hzFps3 = None
edit60hzFps4 = None

edit50hzFps1 = None
edit50hzFps2 = None
edit50hzFps3 = None
edit50hzFps4 = None

edit24hzFps1 = None
edit24hzFps2 = None
edit24hzFps3 = None
edit24hzFps4 = None


# temporary (global but not saved)
lastPlayedMediaType = None

